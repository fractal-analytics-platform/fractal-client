"""
`tasks` module

Submodules:
    * [task collection](collection)
    * [`dummy` task](dummy)
    * [`dummy_parallel` task](dummy_parallel)
"""
